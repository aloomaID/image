---
name: Feature Request
about: Suggest an idea for MoviePy
title: ''
labels: feature-request
assignees: ''

---


