---
name: Question
about: Ask a question about how to use MoviePy
title: ''
labels: question
assignees: ''

---

<!--
Hello! If you think that it is a simple problem, then consider asking instead on our Gitter channel: https://gitter.im/movie-py/. This makes it easier to have a back-and-forth discussion in real-time.
 
--------------------

You can format code by putting ``` (that's 3 backticks) on a line by itself at the beginning and end of each code block. For example:

```
from moviepy import *
clip = ColorClip((600, 400), color=(255, 100, 0), duration=2)
```
-->
