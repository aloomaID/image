import os
os.environ["IMAGEIO_FFMPEG_EXE"] = "C:\\ffmpeg\\bin\\ffmpeg.exe"

from moviepy.editor import *
from PIL import Image
import calendar
import random





def create_receipt_A(business_name, business_address, business_date, due_date, above_random, total_number, last_payment, below_random, add_random, middle_random, dept, input, final_output, output="media/output/re.png"):    
    image_clip1= ImageClip(input)
    #add name and address to image
    generator1 = TextClip(business_name, font='Arial-Bold',align='West', fontsize=27, color='black', size = (1000, 700), method='caption')
    generator2 = TextClip(business_address, font='P052-Bold',align='West', fontsize=24, color='black', size = (1000, 700), method='caption')
    generator3 = TextClip(business_name.replace('\n', ' '), font='P052-Bold',align='West', fontsize=18, color='black', size = (1000, 700), method='caption')
    name_address = CompositeVideoClip([image_clip1, generator1.set_position((60,-75)).set_opacity(0.9), generator2.set_position((63,20)).set_opacity(0.8), generator3.set_position((110,980)).set_opacity(0.8), generator2.set_position((101,1025)).set_opacity(0.8) ])
    #add dates to image
    generator4 = TextClip(business_date, font='P052-Bold',align='West', fontsize=21, color='black', size = (1000, 700), method='caption')
    generator5 = TextClip(due_date, font='P052-Bold',align='West', fontsize=21, color='black', size = (1000, 700), method='caption')
    generator6 = TextClip(last_payment, font='P052-Bold',align='West', fontsize=20, color='black', size = (1000, 700), method='caption')
    name_address_date= CompositeVideoClip([name_address, generator4.set_position((947,-260)).set_opacity(0.9), generator5.set_position((1083,-216)).set_opacity(0.9), generator5.set_position((880,12)).set_opacity(0.9), generator6.set_position((764,-38)).set_opacity(0.9)])
    #add random number to image
    generator7 = TextClip(above_random, font='P052-Bold',align='East', fontsize=20, color='black', size = (1000, 700), method='caption')
    generator8 = TextClip(total_number, font='P052-Bold',align='East', fontsize=21, color='black', size = (1000, 700), method='caption')
    generator9 = TextClip(below_random, font='P052-Bold',align='East', fontsize=21, color='black', size = (1000, 700), method='caption')
    generator10 = TextClip(add_random, font='Arial-Bold',align='East', fontsize=23, color='black', size = (1000, 700), method='caption')
    generator11 = TextClip(middle_random, font='P052-Bold',align='West', fontsize=19, color='black', size = (1000, 700), method='caption')
    generator12 = TextClip(dept, font='Arial-Bold',align='East', fontsize=24, stroke_width=.7, stroke_color = 'white', color='white', size = (1000, 700), method='caption')
    name_address_date_num= CompositeVideoClip([name_address_date, generator7.set_position((210,308)).set_opacity(0.9), generator8.set_position((210,493)).set_opacity(0.9), generator9.set_position((210,-24)).set_opacity(0.9), generator10.set_position((210,63)).set_opacity(0.9), generator11.set_position((948,-215)).set_opacity(0.9), generator10.set_position((62,909)).set_opacity(0.9), generator12.set_position((-85,547)).set_opacity(0.9)])
    #add city to image
    generator13 = TextClip(business_address.replace('\n', " "), font='P052-Bold',align='West', fontsize=18, color='black', size = (1000, 700), method='caption')
    result= CompositeVideoClip([name_address_date_num, generator13.set_position((75,918)).set_opacity(0.7)])
    video = result.save_frame(output)
    im = Image.open(output).convert("RGB")
    im.save(final_output, quality=95, optimize=True)
    os.remove(output)
    
    
def create_receipt_B(business_name, business_address, business_date, last_payment, num_date, num_random, num_random1, num_random2, num_random3, num_random4, num_random5, num_random6, city, input, final_output, output="media/output/re.png"):      
    image_clip1= ImageClip(input)
    #add name and address to image
    generator1 = TextClip(business_name, font='Arial-Bold',align='West', fontsize=10, color='black', size = (1000, 700), method='caption')
    generator2 = TextClip(business_address, font='P052-Bold',align='West', fontsize=9, color='black', size = (1000, 700), method='caption')
    name_address = CompositeVideoClip([image_clip1, generator1.set_position((20,-240)).set_opacity(0.9), generator2.set_position((21,-210)).set_opacity(0.8) ])
    #add dates to image
    generator3 = TextClip(business_date, font='Arial-Bold',align='West', fontsize=9, color='black', size = (1000, 700), method='caption')
    generator4 = TextClip(business_date, font='Arial-Bold',align='West', fontsize=9, color='#8A4D3A', size = (1000, 700), method='caption')
    generator5 = TextClip(last_payment, font='Arial-Bold',align='West', fontsize=9, color='black', size = (1000, 700), method='caption')
    generator6 = TextClip(num_date, font='P052-Bold',align='West', fontsize=9, color='black', size = (1000, 700), method='caption')
    name_address_date = CompositeVideoClip([name_address, generator3.set_position((370,-310)).set_opacity(0.9), generator4.set_position((359,-298)).set_opacity(0.8), generator5.set_position((70,-20)).set_opacity(0.9), generator5.set_position((118,99)).set_opacity(0.9), generator6.set_position((309,70)).set_opacity(0.9) ])
    #add random number to image
    generator7 = TextClip(num_random, font='P052-Bold',align='West', fontsize=9, color='black', size = (1000, 700), method='caption')
    generator8 = TextClip(num_random1, font='P052-Bold',align='West', fontsize=9, color='black', size = (1000, 700), method='caption')
    generator9 = TextClip(num_random2, font='Arial-Bold',align='East', fontsize=9, color='black', size = (500, 688), method='caption')
    generator10 = TextClip(num_random3, font='Arial-Bold',align='East', fontsize=10, color='black', size = (500, 688), method='caption')
    generator11 = TextClip(num_random4, font='Arial-Bold',align='East', fontsize=10, color='black', size = (500, 688), method='caption')
    generator12 = TextClip(num_random5, font='Arial-Bold',align='East', fontsize=10, color='black', size = (500, 688), method='caption')
    generator13 = TextClip(num_random6, font='Arial-Bold',align='West', fontsize=10, color='black', size = (1000, 700), method='caption')
    name_address_date_num = CompositeVideoClip([name_address_date, generator7.set_position((312,45)).set_opacity(0.9), generator8.set_position((312,18)).set_opacity(0.9), generator9.set_position((-212,-105)).set_opacity(0.9), generator10.set_position((-212,11)).set_opacity(0.9), generator11.set_position((-263,65)).set_opacity(0.9), generator12.set_position((-212,96)).set_opacity(0.9), generator13.set_position((438,-240)).set_opacity(0.9)  ])
    #add few random number and city to image
    r_random13= str(round(random.uniform(200.00, 299.00), 2))
    r_random14= str(round(random.uniform(200.00, 299.00), 2))
    r_random15= str(round(random.uniform(200.00, 299.00), 2))
    generator14 = TextClip(city, font='Arial-Bold',align='West', fontsize=7, color='black', size = (1000, 700), method='caption')
    generator15 = TextClip(r_random13, font='Arial-Bold',align='West', fontsize=9, color='black', size = (1000, 700), method='caption')
    generator16 = TextClip(r_random14, font='Arial-Bold',align='West', fontsize=9, color='black', size = (1000, 700), method='caption')
    generator17 = TextClip(r_random15, font='Arial-Bold',align='West', fontsize=9, color='black', size = (1000, 700), method='caption')
    result = CompositeVideoClip([name_address_date_num, generator14.set_position((19,-281)).set_opacity(0.7), generator15.set_position((460,-117)).set_opacity(0.9), generator16.set_position((470,-100)).set_opacity(0.9), generator17.set_position((467,-83)).set_opacity(0.9)])
    video = result.save_frame(output)
    im = Image.open(output).convert("RGB")
    im.save(final_output, quality=95, optimize=True)
    os.remove(output)

def create_receipt_C(business_name, business_address, business_date, due_date, last_payment, ll_payment, snum_random1, snum_random2, snum_random3, snum_random4, snum_random5, snum_random6, snum_random7, snum_random8, snum_random9, input, final_output, output="media/output/re.png"):    
    image_clip1= ImageClip(input)
    #add name and address to image
    generator1 = TextClip(business_name, font='Arial-Bold',align='West', fontsize=20, color='black', size = (1000, 700), method='caption')
    generator2 = TextClip(business_address, font='P052-Bold',align='West', fontsize=18, color='black', size = (1000, 700), method='caption')
    name_address = CompositeVideoClip([image_clip1, generator1.set_position((165,90)).set_opacity(0.9), generator2.set_position((166,139)).set_opacity(0.8) ])
    #add dates to image
    generator3 = TextClip(business_date, font='P052-Bold',align='West', fontsize=20, color='black', size = (1000, 700), method='caption')
    generator4 = TextClip(due_date, font='P052-Bold',align='West', fontsize=20, color='black', size = (1000, 700), method='caption')
    generator5 = TextClip(last_payment.replace('/2023', ''), font='P052-Bold',align='West', fontsize=16, color='black', size = (1000, 700), method='caption')
    generator6 = TextClip(ll_payment.replace('/2023', ''), font='P052-Bold',align='West', fontsize=16, color='black', size = (1000, 700), method='caption')
    name_address_date = CompositeVideoClip([name_address, generator3.set_position((687,-150)).set_opacity(0.9), generator4.set_position((870,942)).set_opacity(0.9), generator5.set_position((195,310)).set_opacity(0.9), generator6.set_position((310,310)).set_opacity(0.9)])
    #add random number to image
    generator7 = TextClip(snum_random1, font='P052-Bold',align='East', fontsize=14, color='black', size = (1275, 1650), method='caption')
    generator8 = TextClip(snum_random2, font='P052-Bold',align='West', fontsize=18, color='black', size = (1000, 700), method='caption')
    generator9 = TextClip(snum_random3, font='P052-Bold',align='West', fontsize=17, color='black', size = (1000, 700), method='caption')
    generator10 = TextClip(snum_random4, font='Arial-Bold',align='West', fontsize=20, color='black', size = (1000, 700), method='caption')
    generator11 = TextClip(snum_random5, font='P052-Bold',align='West', fontsize=17, color='black', size = (1000, 700), method='caption')
    generator12 = TextClip(snum_random6, font='Arial-Bold',align='East', fontsize=19, color='black', size = (1275, 1650), method='caption')
    generator13 = TextClip(snum_random7, font='P052-Bold',align='East', fontsize=18, color='black', size = (1275, 1650), method='caption')
    generator14 = TextClip(snum_random8, font='P052-Bold',align='East', fontsize=18, color='black', size = (1275, 1650), method='caption')
    name_address_date_num = CompositeVideoClip([name_address_date, generator7.set_position((-150,-491)).set_opacity(0.9), generator8.set_position((805,475)).set_opacity(0.9), generator9.set_position((265,453)).set_opacity(0.9), generator10.set_position((840,-150)).set_opacity(0.9), generator11.set_position((107,310)).set_opacity(0.9), generator12.set_position((-240,438)).set_opacity(0.9), generator13.set_position((-165,487)).set_opacity(0.9), generator14.set_position((-152,120)).set_opacity(0.9)])
    #add few random number and city to image
    generator15 = TextClip(snum_random9, font='P052-Bold',align='East', fontsize=18, color='black', size = (1275, 1650), method='caption')
    g_random= str(round(random.uniform(14000, 16000)))
    generator16 = TextClip(g_random, font='Arial-Bold',align='West', fontsize=16, color='black', size = (1000, 700), method='caption')
    result = CompositeVideoClip([name_address_date_num, generator15.set_position((-700,-23)).set_opacity(0.9), generator16.set_position((1090,310)).set_opacity(0.9)])
    video = result.save_frame(output)
    im = Image.open(output).convert("RGB")
    im.save(final_output, quality=95, optimize=True)
    os.remove(output)
    
def create_receipt_D(business_name, business_address, business_date, input, final_output, output="media/output/re.png"):
    image_clip1= ImageClip(input)
    generator1 = TextClip(business_name, font='Arial-Bold',align='West', fontsize=25, color='black', size = (1000, 700), method='caption')
    generator2 = TextClip(business_address, font='P052-Bold',align='West', fontsize=23, color='black', size = (1000, 700), method='caption')
    #add name and address to image
    result = CompositeVideoClip([image_clip1, generator1.set_position((85,-55)).set_opacity(0.9), generator2.set_position((88,0)).set_opacity(0.8) ])
    video = result.save_frame(output)
    im = Image.open(output).convert("RGB")
    im.save(final_output, quality=95, optimize=True)
    os.remove(output)
    
def create_receipt_E(business_name, business_address, business_date, input, final_output, output="media/output/re.png"):
    image_clip1= ImageClip(input)
    generator1 = TextClip(business_name, font='Arial-Bold',align='West', fontsize=25, color='black', size = (1000, 700), method='caption')
    generator2 = TextClip(business_address, font='P052-Bold',align='West', fontsize=23, color='black', size = (1000, 700), method='caption')
    #add name and address to image
    result = CompositeVideoClip([image_clip1, generator1.set_position((55,-70)).set_opacity(0.9), generator2.set_position((56,-10)).set_opacity(0.8), generator1.set_position((200,1330)).set_opacity(0.9), generator2.set_position((201,1390)).set_opacity(0.8) ])
    video = result.save_frame(output)
    im = Image.open(output).convert("RGB")
    im.save(final_output, quality=95, optimize=True)
    os.remove(output)
    
def create_receipt_F(hnum_random1, hnum_random2, hnum_random3, hnum_random4, hnum_random5, h_random2, input, final_output, output="media/output/re.png"):
    image_clip1= ImageClip(input)
    generator1 = TextClip(hnum_random1, font='P052-Bold',align='West', fontsize=30, color='black', size = (1000, 700), method='caption')
    generator2 = TextClip(hnum_random2, font='Arial-Bold',align='West', fontsize=27, color='black', size = (1000, 700), method='caption')
    generator3 = TextClip(hnum_random3, font='P052-Bold',align='West', fontsize=28, color='black', size = (1300, 700), method='caption')
    generator4 = TextClip(hnum_random4, font='P052-Bold',align='West', fontsize=27, color='black', size = (1300, 700), method='caption')
    generator5 = TextClip(hnum_random5, font='P052-Bold',align='West', fontsize=28, color='black', size = (1300, 700), method='caption')
    generator6= TextClip(h_random2, font='Arial-Bold',align='West', fontsize=30, color='black', size = (1300, 700), method='caption')
    #add name and address to image
    result = CompositeVideoClip([image_clip1, generator1.set_position((763,110)).set_opacity(0.9), generator2.set_position((585,-268)).set_opacity(0.9), generator3.set_position((357,845)).set_opacity(0.9), generator4.set_position((357,1095)).set_opacity(0.9), generator5.set_position((212,874)).set_opacity(0.9), generator6.set_position((1400,-275)).set_opacity(0.9)])
    video = result.save_frame(output)
    im = Image.open(output).convert("RGB")
    im.save(final_output, quality=95, optimize=True)
    os.remove(output)
    
def create_receipt_G(gnum_random1, business_owner, gnum_random2, input, final_output, output="media/output/re.png"):
    image_clip1= ImageClip(input)
    generator1 = TextClip(gnum_random1, font='Arial-Bold',align='West', fontsize=32, color='black', size = (2000, 700), method='caption')
    generator2 = TextClip(business_owner, font='Arial-Bold',align='West', fontsize=32, color='black', size = (2000, 700), method='caption')
    generator3 = TextClip(gnum_random2, font='Arial-Bold',align='West', fontsize=32, color='black', size = (2000, 700), method='caption')
    #add name and address to image
    result = CompositeVideoClip([image_clip1, generator1.set_position((160,600)).set_opacity(0.9), generator2.set_position((765,1565)).set_opacity(0.9), generator3.set_position((1150,-75)).set_opacity(0.9)])
    video = result.save_frame(output)
    im = Image.open(output).convert("RGB")
    im.save(final_output, quality=95, optimize=True)
    os.remove(output)
    
def create_receipt_H(business_name, business_date, h_random1, input, final_output, output="media/output/re.png"):
    image_clip1= ImageClip(input)
    generator1 = TextClip(business_name.replace('\n', ' '), font='Arial-Bold',align='West', fontsize=32, color='black', size = (2000, 700), method='caption')
    generator2 = TextClip(business_date, font='Arial-Bold',align='West', fontsize=32, color='black', size = (2000, 700), method='caption')    
    generator3 = TextClip(h_random1, font='P052-Bold',align='West', fontsize=32, color='black', size = (2000, 700), method='caption') 
    
    #add name and address to image
    result = CompositeVideoClip([image_clip1, generator1.set_position((640,630)).set_opacity(0.9), generator2.set_position((248,770)).set_opacity(0.9), generator2.set_position((900,962)).set_opacity(0.9), generator3.set_position((1420,-160)).set_opacity(0.9)])
    video = result.save_frame(output)
    im = Image.open(output).convert("RGB")
    im.save(final_output, quality=95, optimize=True)
    os.remove(output)
    
def create_receipt_I(business_name, inum_random1, ibuss, inum_random2, inum_random3, business_date, i_random1, input, final_output, output="media/output/re.png"):
    image_clip1= ImageClip(input)
    generator1 = TextClip(business_name, font='P052-Bold',align='West', fontsize=26, color='black', size = (2000, 700), method='caption')
    generator2 = TextClip(inum_random1, font='P052-Bold',align='West', fontsize=26, color='black', size = (2000, 700), method='caption')
    generator3 = TextClip(ibuss, font='P052-Bold',align='West', fontsize=26, color='black', size = (2000, 700), method='caption')
    generator4 = TextClip(inum_random2, font='P052-Bold',align='West', fontsize=26, color='black', size = (1000, 700), method='caption')
    generator5 = TextClip(inum_random3, font='Arial-Bold',align='West', fontsize=18, color='black', size = (1000, 700), method='caption')
    generator6 = TextClip(business_date, font='P052-Bold',align='West', fontsize=26, color='black', size = (1000, 700), method='caption')
    generator7 = TextClip(i_random1, font='Arial-Bold',align='West', fontsize=20, color='black', size = (1000, 700), method='caption')
    #add name and address to image
    result = CompositeVideoClip([image_clip1, generator1.set_position((400,70)).set_opacity(0.9), generator2.set_position((500,507)).set_opacity(0.9), generator3.set_position((400,715)).set_opacity(0.9), generator4.set_position((205,1030)).set_opacity(0.9), generator5.set_position((1332,-180)).set_opacity(0.9), generator6.set_position((355,905)).set_opacity(0.9), generator7.set_position((1260,-230)).set_opacity(0.9)])
    video = result.save_frame(output)
    im = Image.open(output).convert("RGB")
    im.save(final_output, quality=95, optimize=True)
    os.remove(output)
    
def create_receipt_J(jnum_random1, business_date, input, final_output, output="media/output/re.png"):
    image_clip1= ImageClip(input)
    generator1 = TextClip(jnum_random1, font='P052-Bold',align='West', fontsize=50, color='black', size = (2000, 700), method='caption')
    generator2 = TextClip(business_date, font='P052-Bold',align='West', fontsize=50, color='black', size = (2000, 700), method='caption')
    bu= business_date.split(',')
    addre= str(bu[0])
    addre1= str(bu[1])
    generator3 = TextClip(addre, font='P052-Bold',align='West', fontsize=50, color='black', size = (2000, 700), method='caption')
    generator4 = TextClip(addre1, font='P052-Bold',align='West', fontsize=50, color='black', size = (2000, 700), method='caption')
    result = CompositeVideoClip([image_clip1, generator1.set_position((1000,1100)).set_opacity(0.9), generator2.set_position((1470,1300)).set_opacity(0.9), generator2.set_position((950,2060)).set_opacity(0.9), generator3.set_position((1980,1525)).set_opacity(0.9), generator4.set_position((320,1582)).set_opacity(0.9) ])
    video = result.save_frame(output)
    im = Image.open(output).convert("RGB")
    im.save(final_output, quality=95, optimize=True)
    os.remove(output)
    
    
    
def randomdate(year, month, con):
    algo= ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'oct', 'Nov', 'Dec']
    dates = calendar.Calendar().itermonthdates(year, month)
    date= random.choice([date for date in dates if date.month == month])
    day= date.day
    year= date.year
    month= date.month
    if con =="normal":
        business_date= f'{day}/{month}/{year}'
    else:
        business_date= f'{algo[int(month)-1]} {day}, {year}'
    return business_date



    
if __name__ == '__main__':
    template= str(input("Choose Your Prefarable Country template: \n(A): Random template\n(B): Arizona\n(C): California\n(D): Georgia\n(E): Missouri\n(F): Virginia\n")).lower()
    if template == "a":
        city= str(input("Enter the city (E.g richmond, ga) below:\n")).title()
        template= random.choice(['a', 'b', 'c'])
    elif template == "b":
        business_owner= str(input("Enter the owner account name below:\n"))
        wedsite= str(input("Enter the owner account website below:\n"))
        template="f"
    elif template == "c":
        business_owner= str(input("Enter the owner_account name below:\n")).title()
        gzip= str(input("Enter the address zip code below:\n"))
        gstates= str(input("Enter the address state below:\n"))
        gcity= str(input("Enter the address city below:\n"))
        gaddress= str(input("Enter the short address below:\n"))
        template="g"
    elif template == "d":
        template="h"
    elif template == "e":
        template="j"
    elif template == "f":
        business_owner= str(input("Enter the owner_account name below:\n"))
        wedsite= str(input("Enter the owner account website below:\n"))
        gcity= str(input("Enter the owner account city below:\n"))
        template="i"
        
    title_name= str(input("Enter the business name below:\n")).title()
    title_address= str(input("Enter the business address below:\n")).title()
    
    sear_nu= len(title_name.split(' '))
    if sear_nu <=4:
        business_name= title_name
    else:
        business_name= ""
        g=4
        chunks = [" ".join(title_name.split()[a:a+g]) for a in range(0, len(title_name), g)]
        y=0
        for j in chunks:
            if not j.strip():
                break
            y+=1
            if y== 1:
                business_name += f'{j}\n'
            else:
                business_name += f'{j}'
                
    sear_num= len(title_address.split(' '))
    if sear_num <=3:
        business_address= title_address
    else:
        business_address= ""
        g=3
        chunks = [" ".join(title_address.split()[a:a+g]) for a in range(0, len(title_address), g)]
        y=0
        for j in chunks:
            if not j.strip():
                break
            y+=1
            if y== 1:
                business_address += f'{j}\n'
            else:
                business_address += f'{j}'
    
    
    
    business_date = randomdate(2023, 7, con='normal')
    due_date = randomdate(2023, 8, con='normal')
    last_payment= randomdate(2023, 6, con='normal')
    ll_payment= randomdate(2023, 5, con='normal')
    if template.lower() == "a":
        #random list1
        input= "media/input/Jorge LLC.jpg"
        final_output="media/output/Jorge LLC.jpg"
        one_number= round(random.uniform(115.00, 190.00), 2)
        two_number= round(random.uniform(50.00, 100.00), 2)
        three_number= round(random.uniform(0.00, 10.00), 2)
        four_number= round(random.uniform(0.00, 5.00), 2)
        five_number= round(random.uniform(0.00, 5.00), 2)
        six_number= round(random.uniform(0.00, 5.00), 2)
        seven_number= round(random.uniform(10.00, 25.00), 2)
        total_number= f'${round((one_number+two_number+three_number+four_number+five_number+six_number+seven_number), 2)}'
        above_random=f"{one_number}\n\n{two_number}\n\n{three_number}\n\n{four_number}\n\n{five_number}\n\n{six_number}\n\n{seven_number}"
        
        #random list2
        new1_random= round(random.uniform(400.00, 500.00), 2)
        new2_random= round(random.uniform(200.00, 299.00), 2)
        sub_random= round((new1_random - new2_random), 2)
        add_random= f'${round((sub_random + float(total_number.replace("$", ""))), 2)}'
        below_random=f'{new1_random}\n-{new2_random}\n{sub_random}\n-{total_number.replace("$", "")}'
        middle_random= f'${sub_random}\n{total_number}\n{add_random}'
        dept= f'${one_number- 10}'
        create_receipt_A(business_name, business_address, business_date, due_date, above_random, total_number, last_payment, below_random, add_random, middle_random, dept, input, final_output)
        print('Completed')
    elif template.lower() == "b":
        input= "media/input/Miller Utility Bill.jpg"
        final_output="media/output/Miller Utility Bill.jpg"
        
        num_date= f'{ll_payment}        {last_payment}          {due_date}'
        r_random1= round(random.uniform(6000.00, 6199.00), 2)
        r_random2= round(random.uniform(6200.00, 6400.00), 2)
        r_random3= round(random.uniform(500000.00, 600000.00), 2)
        num_random= f'{r_random1}          {r_random2}          {r_random3}'
        r_random4= round(random.uniform(20.00, 30.00), 2)
        r_random5= round(random.uniform(200.00, 250.00), 2)
        r_random6= round(random.uniform(250.00, 300.00), 2)
        num_random1= f'{r_random4}               {r_random5}               {r_random6}'
        r_random7= round(random.uniform(80.00, 90.00), 2)
        num_random2= f'${r_random7}\n{r_random7}\n\n\n{r_random7}\n${r_random7}'
        r_random8= round(random.uniform(110.00, 190.00), 2)
        add_num1= round((r_random7 + r_random8), 2)
        num_random3= f'${r_random8}\n{r_random7}\n{add_num1}'
        r_random9= round(random.uniform(90.00, 99.00), 2)
        r_random10= round(random.uniform(40.00, 50.00), 2)
        r_random11= round(random.uniform(10.00, 19.00), 2)
        num_random4= f'${r_random9}\n{r_random10}\n{r_random11}'
        add_num2= round((r_random9 + r_random10 + r_random11), 2)
        add_num3= round((add_num2 + add_num1), 2)
        num_random5= f'{add_num2}\n${add_num3}'
        r_random12= round(random.uniform(10000.00, 10999.00), 2)
        num_random6= f'{r_random7}\n\n\n\n\n\n\n\n\n{r_random12}'
        create_receipt_B(business_name, business_address, business_date, last_payment, num_date, num_random, num_random1, num_random2, num_random3, num_random4, num_random5, num_random6, city, input, final_output)
        print('Completed')
    elif template.lower() == "c":
        input= "media/input/Electricity-Bill_.jpg"
        final_output="media/output/Electricity-Bill_.jpg"
        s_random1= round(random.uniform(130.00, 199.00), 2)
        s_random2= round(random.uniform(101.00, 129.00), 2)
        s_random3= round(random.uniform(20.00, 50.00), 2)
        s_random4= round(random.uniform(51.00, 100.00), 2)
        s_add1= round((s_random1 - s_random2 + s_random3 + s_random4), 2)
        snum_random1= f'{s_random1}\n-{s_random2}\n0.00\n\n{s_random3}\n{s_random4}\n\n{s_add1}'
        s_random5= round(random.uniform(700.00, 790.00), 2)
        s_random6= round(random.uniform(201.00, 299.00), 2)
        s_random7= round(random.uniform(901.00, 999.00), 2)
        s_random8= round(random.uniform(0.05814, 0.09814), 5)
        s_random9= round(random.uniform(0.04014, 0.05814), 5)
        s_random10= round(random.uniform(0.00302, 0.00399), 5)
        s_random11= round(random.uniform(0.00202, 0.00292), 5)
        s_random12= round(random.uniform(0.01502, 0.01592), 5)
        s_random13= round(random.uniform(0.02010, 0.02999), 5)
        s_random14= round(random.uniform(0.000151, 0.000171), 6)
        s_random15= round(random.uniform(0.00081, 0.00099), 5)
        s_add2= round((s_random5 * s_random8), 2)
        s_add3= round((s_random6 * s_random9), 2)
        s_add4= round((s_random7 * s_random10), 2)
        s_add5= round((s_random7 * s_random11), 2)
        s_add6= round((s_random7 * s_random12), 2)
        snum_random2= f'{s_random5}               {s_random8}             ${s_add2}\n{s_random6}               {s_random9}             ${s_add3}\n\n{s_random7}               {s_random10}             ${s_add4}\n\n{s_random7}               {s_random11}             ${s_add5}\n{s_random7}               {s_random12}             ${s_add6}'
        snum_random3= f'{s_random7}               {s_random13}\n{s_random7}               {s_random14}\n{s_random7}               {s_random15}'
        s_random16= round(random.uniform(3000000, 3999999))
        s_random17= round(random.uniform(90000000, 99999999))
        snum_random4= f'{s_random16}                  {s_random17}'
        s_random18= round(random.uniform(900, 999))
        snum_random5= f'{s_random16}                                                                               {s_random18}'
        snum_random6= f'{s_random17}        {business_name}'
        s_random18= round(random.uniform(101.00, 129.00), 2)
        snum_random7= f'{s_random18}\n\n{s_random18}'
        s_add7= round((s_add2 + s_add3 + s_add4 + s_add5 + s_add6), 2)
        snum_random8= f'${s_add7}\n\n${s_add7}'
        s_random19= round(random.uniform(6.00, 10.00), 2)
        s_add8= round((s_random7 * s_random13), 2)
        s_add9= round((s_random7 * s_random14), 2)
        s_add10= round((s_random7 * s_random15), 2)
        s_add11 = round((s_add8 + s_add9 + s_add10 + s_random19), 2)
        snum_random9= f'$0.00\n${s_random19}\n\n\n\n\n\n\n${s_add11}'
        create_receipt_C(business_name, business_address, business_date, due_date, last_payment, ll_payment, snum_random1, snum_random2, snum_random3, snum_random4, snum_random5, snum_random6, snum_random7, snum_random8, snum_random9, input, final_output)
        print('Completed')
    elif template.lower() == "d":
        input= "media/input/waterbill.jpg"
        final_output="media/output/waterbill.jpg"
        create_receipt_D(business_name, business_address, business_date, input, final_output)
        print('Completed')
    elif template.lower() == "e":
        input= "media/input/Sweet Beginnings Bridal.jpg"
        final_output="media/output/Sweet Beginnings Bridal.jpg"
        create_receipt_E(business_name, business_address, business_date, input, final_output)
        print('Completed')
    elif template.lower() == "f":
        input= "media/input/ArizonaDocuments.jpg"
        final_output="media/output/ArizonaDocuments.jpg"
        h_random1= round(random.uniform(1200000, 1800000))
        hnum_random1= f'{business_name}\n{h_random1}\n{business_date}'
        hnum_random2= f'        {business_date}\n{business_date}'
        buss= business_address.replace('\n', '')
        hnum_random3= f"{business_owner}- {buss} {wedsite}"
        hnum_random4= f'{business_owner}  {business_date}'
        hnum_random5= f'{business_date}\n\n\n\n{business_date}'
        h_random2= str(round(random.uniform(10000000000001, 20000000000000)))
        create_receipt_F(hnum_random1, hnum_random2, hnum_random3, hnum_random4, hnum_random5, h_random2, input, final_output)
        print('Completed')
    elif template.lower() == "g":
        input= "media/input/California License.jpg"
        final_output="media/output/California License.jpg"
        
        g_random1= str(round(random.uniform(200000000001, 299999999999)))
        gnum_random1=f'{business_name}\n\n\n\n\n\n\n\n\n\n{business_owner}\n\n\n{gaddress}                                                              {gcity}           {gstates}           {gzip}'
        business_date = randomdate(2023, 7, con='noe')
        gnum_random2= f'{g_random1}\n\n\n\n\n\n\n\n\n{business_date}'
        create_receipt_G(gnum_random1, business_owner, gnum_random2, input, final_output)
        print('Completed')
    elif template.lower() == "h":
        input= "media/input/Georgia License.jpg"
        final_output="media/output/Georgia License.jpg"
        business_date = randomdate(2023, 7, con='noe')
        h_random1= str(round(random.uniform(10000001, 19999999)))
        create_receipt_H(business_name, business_date, h_random1, input, final_output)
        print('Completed')
    elif template.lower() == "i":
        input= "media/input/Virginia License.jpg"
        final_output="media/output/Virginia License.jpg"
        
        signature= "ȟȋȽȽ"
        inum_random1= f'                                                                               {gcity}\n\n\n{business_owner}                                                 {wedsite}\n\n\n\n{business_address}'
        ibuss= business_address.replace('\n', ' ')
        inum_random2= f'{business_owner}                                                  {signature}'
        inum_random3= f'{business_date}\n        {business_date}'
        i_random1= str(round(random.uniform(10000001, 20000000)))
        create_receipt_I(business_name, inum_random1, ibuss, inum_random2, inum_random3, business_date, i_random1, input, final_output)
        print('Completed')
    elif template.lower() == "j":
        input= "media/input/Missouri License.jpg"
        final_output="media/output/Missouri License.jpg"
        j_random1= str(round(random.uniform(0000000, 1000000)))
        jnum= f'LC{j_random1}'
        jnum_random1= f'{business_name}\n           {jnum}'
        business_date = randomdate(2023, 7, con='noe')
        create_receipt_J(jnum_random1, business_date, input, final_output)
        print('Completed')
    else:
        print("Out of Options")