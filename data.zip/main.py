from subprocess import call
call(["python", "tests/dd.py"])