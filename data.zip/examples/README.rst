This folder contains curated examples for MoviePy.
