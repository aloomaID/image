.. ref_decorators:

************
Decorators
************
These decorators are implemented to ease the writing of methods and effects in MoviePy

.. automodule:: moviepy.decorators
   :members:
   :inherited-members:
   :show-inheritance:
