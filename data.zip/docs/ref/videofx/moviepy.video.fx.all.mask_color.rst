moviepy\.video\.fx\.all\.mask\_color
====================================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: mask_color