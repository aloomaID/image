moviepy.video.fx.all.multiply_speed
===================================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: multiply_speed