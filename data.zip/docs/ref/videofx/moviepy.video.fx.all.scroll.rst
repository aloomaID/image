moviepy.video.fx.all.scroll
===========================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: scroll