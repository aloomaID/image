moviepy\.video\.fx\.all\.freeze\_region
=======================================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: freeze_region