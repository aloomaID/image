moviepy\.video\.fx\.all\.invert\_colors
=======================================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: invert_colors