moviepy.video.fx.all.fadein
===========================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: fadein