.. _ffmpegTools:

FFMPEG tools
----------------------------

.. automodule:: moviepy.video.io.ffmpeg_tools
   :members:
   :inherited-members:
   :undoc-members:
   :show-inheritance:
