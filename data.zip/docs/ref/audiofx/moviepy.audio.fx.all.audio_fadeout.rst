moviepy.audio.fx.all.audio_fadeout
==================================

.. currentmodule:: moviepy.audio.fx.all

.. autofunction:: audio_fadeout