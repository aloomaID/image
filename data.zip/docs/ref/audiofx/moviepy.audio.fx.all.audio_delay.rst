moviepy.audio.fx.all.audio_delay
================================

.. currentmodule:: moviepy.audio.fx.all

.. autofunction:: audio_delay