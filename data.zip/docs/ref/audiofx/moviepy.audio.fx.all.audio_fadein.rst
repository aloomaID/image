moviepy.audio.fx.all.audio_fadein
=================================

.. currentmodule:: moviepy.audio.fx.all

.. autofunction:: audio_fadein